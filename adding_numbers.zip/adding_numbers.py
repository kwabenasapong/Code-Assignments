#Program to Add to numbers

#Declare integer variables here
a = 2
b = 3
result = 0

#Sum results here
result = a + b
print(result)
